﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity;

namespace Axantum.Xecrets.Core
{
    public static class Resolve
    {
        private static IUnityContainer _container = new UnityContainer();

        public static IUnityContainer Container
        {
            get { return _container; }
        }

        public static T New<T>()
        {
            return _container.Resolve<T>();
        }
    }
}
