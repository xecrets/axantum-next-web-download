﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace Axantum.Xecrets.Core
{
    public class ProtectedDataImpl : IProtectedData
    {
        #region IProtectedData Members

        public byte[] Protect(byte[] userData, byte[] optionalEntropy, System.Security.Cryptography.DataProtectionScope scope)
        {
            return ProtectedData.Protect(userData, optionalEntropy, DataProtectionScope.LocalMachine);
        }

        public byte[] Unprotect(byte[] encryptedData, byte[] optionalEntropy, System.Security.Cryptography.DataProtectionScope scope)
        {
            return ProtectedData.Unprotect(encryptedData, optionalEntropy, DataProtectionScope.LocalMachine);
        }

        #endregion
    }
}
