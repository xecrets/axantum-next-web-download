﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace Axantum.Xecrets.Core
{
    /// <summary>
    /// A simple fixed-specification encryption wrapper for byte-arrays, intended to be easily
    /// inter operable between environments and easy and safe to use. It uses
    /// a varying length hash in order to be somewhat more compact. It is intended for typical ephemeral encryption over
    /// for example web requests or similar. The algorithm is AES-128-CBC or AES-256-CBC, the hash is SHA-256
    /// truncated to use the leftmost msb bytes as appropriate.
    /// The format is:
    /// < IV > 16 bytes.
    /// < begin encrypted part AES-128-CBC or AES-256-CBC >
    /// < length(message) > 3 bytes.
    /// < length(hash) > 1 byte.
    /// < message: the plain text message >
    /// < hash: the SHA-256(length(message) || length(hash) || message) truncated to length(hash) >
    /// 
    /// length(hash) is calculated as:
    /// 
    /// data_length = 4 + length(message);
    /// length = data_length % 16 - 1;
    /// if (length < 8 || data_length < 16) length += 16;
    /// 
    /// The message lengths + message + hash is then encrypted using AES-128-CBC or AES-256-CBC with PKCS7 style padding.
    /// Decryption first validates padding, then message length and finally the hash.
    /// </summary>
    public class Ximple
    {
        public delegate byte[] RandomNumberGeneratorDelegate(int count);

        private static readonly RandomNumberGenerator _rng = new RNGCryptoServiceProvider();

        private RandomNumberGeneratorDelegate _randomNumberGenerator;

        public static byte[] RandomNumberGenerator(int count)
        {
            if (count < 0)
            {
                throw new ArgumentOutOfRangeException("count");
            }
            byte[] bytes = new byte[count];
            _rng.GetBytes(bytes);

            return bytes;
        }

        private byte[] _key;

        public byte[] Key
        {
            get
            {
                byte[] key = new byte[_key.Length];
                _key.CopyTo(key, 0);
                return key;
            }
        }

        public Ximple(RandomNumberGeneratorDelegate randomNumberGenerator, byte[] key)
        {
            if (key == null)
            {
                throw new ArgumentNullException("key");
            }
            _randomNumberGenerator = randomNumberGenerator;

            if (key.Length != 16)
            {
                throw new CryptographicException("Only 128-bit/16-byte keys are supported.");
            }
            _key = (byte[])key.Clone();
        }

        public Ximple(RandomNumberGeneratorDelegate randomNumberGenerator) : this(randomNumberGenerator, randomNumberGenerator(16))
        {
        }

        public byte[] Encrypt(byte[] bytes)
        {
            if (bytes == null)
            {
                throw new ArgumentNullException("bytes");
            }
            if (bytes.LongLength > Int32.MaxValue)
            {
                throw new ArgumentOutOfRangeException("bytes");
            }
            using (Aes aes = new AesManaged())
            {
                InitAes(aes);
                aes.IV = _randomNumberGenerator(aes.BlockSize / 8);

                byte[] encrypted;
                byte[] lengthInfo = BitConverter.GetBytes(bytes.Length);
                using (ICryptoTransform crypto = aes.CreateEncryptor())
                {
                    byte[] final = crypto.TransformFinalBlock(bytes, 0, bytes.Length);
                    encrypted = new byte[aes.IV.Length + lengthInfo.Length + final.Length];
                    aes.IV.CopyTo(encrypted, 0);
                    lengthInfo.CopyTo(encrypted, aes.IV.Length);
                    final.CopyTo(encrypted, aes.IV.Length + lengthInfo.Length);
                }

                return encrypted;
            }
        }

        private void InitAes(Aes aes)
        {
            aes.Key = _key;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
        }

        public byte[] Decrypt(byte[] bytes)
        {
            if (bytes == null)
            {
                throw new ArgumentNullException("bytes");
            }
            if (bytes.LongLength > Int32.MaxValue)
            {
                throw new ArgumentOutOfRangeException("bytes");
            }
            using (Aes aes = new AesManaged())
            {
                InitAes(aes);
                byte[] iv = new byte[aes.BlockSize / 8];
                Array.Copy(bytes, iv, iv.Length);
                aes.IV = iv;
                int length = BitConverter.ToInt32(bytes, aes.IV.Length);

                byte[] decrypted;
                using (ICryptoTransform crypto = aes.CreateDecryptor())
                {
                    decrypted = crypto.TransformFinalBlock(bytes, aes.IV.Length + sizeof(int), bytes.Length - (aes.IV.Length + sizeof(int)));
                }

                if (length != decrypted.Length)
                {
                    throw new CryptographicException(String.Format("Expected {0} bytes plaintext, but got {1}", length, decrypted.Length));
                }

                return decrypted;
            }
        }
    }
}
