﻿#if DEBUG
#define CODE_ANALYSIS
#endif

#region License

/*
 *  Axantum.Xecrets.Core - Xecrets Core and Reference Implementation
 *
 *  Copyright (C) 2008 Svante Seleborg
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  If you'd like to license this program under any other terms than the
 *  above, please contact the author and copyright holder.
 *
 *  Contact: mailto:svante@axantum.com
 */

#endregion License

#if DEBUG
#define CODE_ANALYSIS
#endif

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Text;

namespace Axantum.Xecrets.Core
{
    public abstract class AppSwitchBase
    {
        private TraceSwitch _traceSwitch;

        protected AppSwitchBase(string displayName)
        {
            _traceSwitch = new TraceSwitch(displayName, displayName);
        }

        public TraceSwitch Switch
        {
            get
            {
                return _traceSwitch;
            }
        }

        protected abstract string Prefix
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether to trace Info, Warning and Error.
        /// </summary>
        /// <value><c>true</c> if [trace info]; otherwise, <c>false</c>.</value>
        public bool TraceInfo
        {
            get
            {
                return _traceSwitch.TraceInfo;
            }
        }

        public void Information(string trace, params object[] args)
        {
            Trace.TraceInformation(SpaceFill("Information", "Information") + Prefix + trace, args);
        }

        /// <summary>
        /// Gets a value indicating whether to trace Warning and Error.
        /// </summary>
        /// <value><c>true</c> if [trace warning]; otherwise, <c>false</c>.</value>
        public bool TraceWarning
        {
            get
            {
                return _traceSwitch.TraceWarning;
            }
        }

        public void Warning(string trace, params object[] args)
        {
            Trace.TraceWarning(SpaceFill("Warning", "Information") + Prefix + trace, args);
        }

        /// <summary>
        /// Gets a value indicating whether to trace Error messages.
        /// </summary>
        /// <value><c>true</c> if [trace error]; otherwise, <c>false</c>.</value>
        public bool TraceError
        {
            get
            {
                return _traceSwitch.TraceError;
            }
        }

        public void Error(string trace, params object[] args)
        {
            Trace.TraceError(SpaceFill("Error", "Information") + Prefix + trace, args);
        }

        /// <summary>
        /// Gets a value indicating whether to trace all, i.e. Verbose, Information, Warning and Error.
        /// </summary>
        /// <value><c>true</c> if [trace verbose]; otherwise, <c>false</c>.</value>
        public bool TraceVerbose
        {
            get
            {
                return _traceSwitch.TraceVerbose;
            }
        }

        public void Verbose(string trace, params object[] args)
        {
            Trace.WriteLine(SpaceFill("Debug", "Information") + String.Format(CultureInfo.InvariantCulture, Prefix + trace, args), "Debug");
        }

        protected static string SpaceFill(string string1, string string2)
        {
            int n = Math.Abs(string1.Length - string2.Length);
            return new string(' ', n);
        }
    }
}