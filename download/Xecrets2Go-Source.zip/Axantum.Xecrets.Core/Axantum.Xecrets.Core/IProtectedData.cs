﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace Axantum.Xecrets.Core
{
    public interface IProtectedData
    {
        /// <summary>
        /// Protects the userData parameter and returns a byte array
        /// </summary>
        /// <param name="userData">A byte array containing data to protect</param>
        /// <param name="optionalEntropy">An additional byte array used to encrypt the data</param>
        /// <param name="scope">One of the System.Security.Cryptography.DataProtectionScope values</param>
        /// <returns>A byte array representing the encrypted data</returns>
        /// <exception cref="System.ArgumentNullException">The userData parameter is null</exception>
        /// <exception cref="System.NotSupportedException">The operating system does not support this method</exception>
        /// <exception cref="System.Security.Cryptography.CryptographicException">The cryptographic protection failed</exception>
        /// <exception cref="System.OutOfMemoryException">Out of memory</exception>
        byte[] Protect(byte[] userData, byte[] optionalEntropy, DataProtectionScope scope);
        /// <summary>
        /// Unprotects the encryptedData parameter and returns a byte array
        /// </summary>
        /// <param name="encryptedData">A byte array containing data encrypted using the System.Security.Cryptography.ProtectedData.Protect(System.Byte[],System.Byte[],System.Security.Cryptography.DataProtectionScope) method</param>
        /// <param name="optionalEntropy">An additional byte array used to encrypt the data</param>
        /// <param name="scope">One of the System.Security.Cryptography.DataProtectionScope values</param>
        /// <returns>A byte array representing the encrypted data</returns>
        /// <exception cref="System.ArgumentNullException">The encryptedData parameter is null</exception>
        /// <exception cref="System.NotSupportedException">The operating system does not support this method</exception>
        /// <exception cref="System.Security.Cryptography.CryptographicException">The cryptographic protection failed</exception>
        /// <exception cref="System.OutOfMemoryException">Out of memory</exception>
        byte[] Unprotect(byte[] encryptedData, byte[] optionalEntropy, DataProtectionScope scope);
    }
}
