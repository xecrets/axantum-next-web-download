#region License
/*
 *  Xecrets2Go - Xecrets Off Line and Reference implementation
 *
 *  Copyright (C) 2008 Svante Seleborg
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  If you'd like to license this program under any other terms than the
 *  above, please contact the author and copyright holder.
 *
 *  Contact: mailto:svante@axantum.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Axantum.Xecrets.Core.Secrets;

namespace Xecrets2Go
{
    public class WinSecret
    {
        Secret _secret;
        string _filter;

        public WinSecret(Secret secret)
        {
            _secret = secret;
        }

        public WinSecret(Secret secret, string filter) : this(secret)
        {
            _filter = filter;
        }

        public string Title
        {
            get
            {
                return System.Net.WebUtility.HtmlDecode(_secret.Title);
            }
        }

        public string Description
        {
            get
            {
                return System.Net.WebUtility.HtmlDecode(_secret.Description);
            }
        }

        public string ShortDescription
        {
            get
            {
                string shortDesc =  Description.Replace(Environment.NewLine, " ");
                int filterPos = shortDesc.IndexOf(_filter, StringComparison.OrdinalIgnoreCase);
                if (filterPos >= 0)
                {
                    int startPos = filterPos - 20;
                    if (startPos > 0)
                    {
                        shortDesc = "... " + shortDesc.Substring(startPos);
                    }
                }
                if (shortDesc.Length > 50)
                {
                    shortDesc = shortDesc.Substring(0, 50) + " ...";
                }
                return shortDesc;
            }
        }

        public string TheSecret
        {
            get
            {
                return System.Net.WebUtility.HtmlDecode(_secret.TheSecret);
            }
        }
    }
}
