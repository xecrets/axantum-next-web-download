#region License
/*
 *  Xecrets2Go - Xecrets Off Line and Reference implementation
 *
 *  Copyright (C) 2008 Svante Seleborg
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  If you'd like to license this program under any other terms than the
 *  above, please contact the author and copyright holder.
 *
 *  Contact: mailto:svante@axantum.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Axantum.Xecrets.Core.Secrets;
using System.IO;
using System.Configuration;
using Axantum.Xecrets.Core;
using System.Security.Cryptography;
using Microsoft.Practices.Unity;

namespace Xecrets2Go
{
    /// <summary>
    /// This program is intended to be useful, and also serve as a demonstration and starting point for development
    /// of an off-line client for the Xecrets password manager at http://www.axantum.com/Xecrets/ .
    /// Along with the Axantum.Xecrets.Core namespace and library, it serves as the reference implementation for peer review
    /// of the storage technique etc. Please send comments to mailto:xecrets@axantum.com .
    /// </summary>
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            RegisterTypesWithUnity();

            string directory = null;

            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            KeyValueConfigurationElement element = config.AppSettings.Settings["DataDirectory"];
            if (element != null)
            {
                directory = element.Value;
            }
            
            DirectoryInfo dir;
            if (String.IsNullOrEmpty(directory))
            {
                // Look in the directory where we are stored. If we find exactly one file matching
                // name pattern for Xecrets XML, open the form directly with this.
                dir = new DirectoryInfo(Application.StartupPath);
            }
            else
            {
                dir = new DirectoryInfo(directory);
            }

            FileInfo[] files = dir.GetFiles("*" + ".xecrets.xml");
            if (files.Length == 1)
            {
                Application.Run(new SearchForm(files[0]));
            }
            else
            {
                Application.Run(new SearchForm());
            }
        }

        private static void RegisterTypesWithUnity()
        {
            Resolve.Container.RegisterType<IProtectedData, ProtectedDataImpl>(new ContainerControlledLifetimeManager());
            Resolve.Container.RegisterType<RandomNumberGenerator, RNGCryptoServiceProvider>(new InjectionConstructor());
            Resolve.Container.RegisterType<TransientProtectedData>();
        }
    }
}