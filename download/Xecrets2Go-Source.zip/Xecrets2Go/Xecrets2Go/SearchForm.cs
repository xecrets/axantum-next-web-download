#region License
/*
 *  Xecrets2Go - Xecrets Off Line and Reference implementation
 *
 *  Copyright (C) 2008 Svante Seleborg
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  If you'd like to license this program under any other terms than the
 *  above, please contact the author and copyright holder.
 *
 *  Contact: mailto:svante@axantum.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Axantum.Xecrets.Core.Persistence;
using Axantum.Xecrets.Core.Secrets;
using System.Configuration;
using System.Reflection;
using System.Globalization;

namespace Xecrets2Go
{
    public partial class SearchForm : Form
    {
        #region Private Fields
        private SecretCollection _secrets = new SecretCollection();
        private EncryptionKeyCollection _keys;
        private FileInfo _file;
        #endregion

        #region Constructors
        public SearchForm()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += new EventHandler(dataGridView1_SelectionChanged);
            SetFilter(String.Empty);
        }

        public SearchForm(FileInfo file) : this()
        {
            OpenFile(file);
        }
        #endregion

        #region Private Helpers
        private void SetFilter(string filter)
        {
            WinSecretCollection filteredCollection = new WinSecretCollection();
            filteredCollection.AddWithFilter(_secrets, filter);
            winSecretCollectionBindingSource.DataSource = filteredCollection;

            if (dataGridView1.Rows.Count > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                dataGridView1.Select();
            }
        }

        private void OpenFile(FileInfo file)
        {
            if (file == null)
            {
                throw new ArgumentNullException("file");
            }

            string username = file.Name;
            if (username.EndsWith(".xecrets.xml", StringComparison.OrdinalIgnoreCase))
            {
                username = username.Substring(0, username.Length - ".xecrets.xml".Length);
            }

            using (Stream stream = new FileStream(file.FullName, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                XmlSecretsReaderWriter secretsReaderWriter = new XmlSecretsReaderWriter(username, stream);

                if (_keys == null || secretsReaderWriter.DetermineFormatConfidence(_keys) != FormatConfidence.Definitely)
                {
                    PasswordDialog dlgPassword = new PasswordDialog(file.Name);
                    switch (dlgPassword.ShowDialog())
                    {
                        case DialogResult.OK:
                            break;
                        default:
                            return;
                    }
                    _keys = new EncryptionKeyCollection(new EncryptionKey(dlgPassword.textBoxPassword.Text), username);
                }

                if (secretsReaderWriter.DetermineFormatConfidence(_keys) != FormatConfidence.Definitely)
                {
                    return;
                }

                _secrets = secretsReaderWriter.FindSecrets(_keys);
                SetFilter(textBoxSearch.Text);

                Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                if (config.AppSettings.Settings["DataDirectory"] == null)
                {
                    config.AppSettings.Settings.Add("DataDirectory", file.DirectoryName);
                }
                else
                {
                    config.AppSettings.Settings["DataDirectory"].Value = file.DirectoryName;
                }
                config.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection("appSettings");

                _file = file;
            }
        }

        private void OpenFile()
        {
            OpenFile(_file);
        }

        private void CloseFile()
        {
            _secrets = new SecretCollection();
            SetFilter(String.Empty);
        }
        #endregion

        #region Control Events
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Assembly a = Assembly.GetEntryAssembly();
            Version version = a.GetName().Version;
            AssemblyProductAttribute[] products = a.GetCustomAttributes(typeof(AssemblyProductAttribute), false) as AssemblyProductAttribute[];
            AssemblyCopyrightAttribute[] copyrights = a.GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false) as AssemblyCopyrightAttribute[];

            // The build number is incremented daily, so we'll just use the day of the first release as an offset.
            string visibleVersion = String.Format(CultureInfo.InvariantCulture, "{0}.{1}.{2}.{3}", version.Major, version.Minor, version.Build - 3054, version.Revision);

            string message = String.Format(CultureInfo.InvariantCulture, "Version {0}, {1}", visibleVersion, copyrights[0].Copyright);
            string caption = String.Format(CultureInfo.InvariantCulture, "About {0}", products[0].Product);
            MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, 0);
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            SetFilter(textBoxSearch.Text);
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseFile();
        }

        void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection rows = dataGridView1.SelectedRows;
            if (rows != null && rows.Count == 1)
            {
                WinSecret secret = rows[0].DataBoundItem as WinSecret;
                textBoxTitle.Text = secret.Title;
                textBoxDescription.Text = secret.Description;
                textBoxTheSecret.Text = secret.TheSecret;
            }
        }

        private void downloadMyXecretsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.axantum.com/Xecrets/LoggedOn/MyXecretsXml.aspx");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void logOnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.axantum.com/Xecrets/LogOn.aspx");
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            switch (openFileDialogMyXecrets.ShowDialog())
            {
                case DialogResult.OK:
                    break;
                default:
                    return;
            }
            OpenFile(new FileInfo(openFileDialogMyXecrets.FileName));
        }

        private void reopenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseFile();
            OpenFile();
        }

        private void searchOnLineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.axantum.com/Xecrets/LoggedOn/Search.aspx");
        }

        private void textBoxTheSecret_Enter(object sender, EventArgs e)
        {
            textBoxTheSecret.UseSystemPasswordChar = false;
        }

        private void textBoxTheSecret_Leave(object sender, EventArgs e)
        {
            textBoxTheSecret.UseSystemPasswordChar = true;
        }

        private void textBoxTheSecret_MouseEnter(object sender, EventArgs e)
        {
            textBoxTheSecret.UseSystemPasswordChar = false;
        }

        private void textBoxTheSecret_MouseLeave(object sender, EventArgs e)
        {
            if (!textBoxTheSecret.Focused)
            {
                textBoxTheSecret.UseSystemPasswordChar = true;
            }
        }
        #endregion
    }
}