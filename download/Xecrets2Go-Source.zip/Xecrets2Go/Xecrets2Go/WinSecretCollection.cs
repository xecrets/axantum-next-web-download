#region License
/*
 *  Xecrets2Go - Xecrets Off Line and Reference implementation
 *
 *  Copyright (C) 2008 Svante Seleborg
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  If you'd like to license this program under any other terms than the
 *  above, please contact the author and copyright holder.
 *
 *  Contact: mailto:svante@axantum.com
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using Axantum.Xecrets.Core.Secrets;

namespace Xecrets2Go
{
    class WinSecretCollection : Collection<WinSecret>
    {
        public void AddWithFilter(SecretCollection secrets, string filter)
        {
            foreach (Secret secret in secrets)
            {
                if (IsInFilter(secret, filter))
                {
                    Add(new WinSecret(secret, filter));
                }
            }
        }

        private static bool IsInFilter(Secret secret, string filter)
        {
            if (String.IsNullOrEmpty(filter))
            {
                return true;
            }
            if (secret.Title.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return true;
            }
            if (secret.Description.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return true;
            }
            if (secret.TheSecret.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return true;
            }
            return false;
        }
    }
}
