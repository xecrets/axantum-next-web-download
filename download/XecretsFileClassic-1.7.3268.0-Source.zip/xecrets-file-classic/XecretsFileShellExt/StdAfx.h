// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

// This is part of enabling XP Visual Styles in a Shell Extension DLL
#define     ISOLATION_AWARE_ENABLED 1
#define _CRT_RAND_S

// Windows Header Files:
#include <windows.h>

// TODO: reference additional headers your program requires here
#include "XecretsFileShellExt.h"
