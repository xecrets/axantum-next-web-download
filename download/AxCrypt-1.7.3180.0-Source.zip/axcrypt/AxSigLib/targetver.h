#ifndef AXSIGLIB_TARGETVER_H
#define AXSIGLIB_TARGETVER_H

// The following macros define the minimum required platform.  The minimum required platform
// is the earliest version of Windows, Internet Explorer etc. that has the necessary features to run 
// your application.  The macros work by enabling all features available on platform versions up to and 
// including the version specified.

#endif