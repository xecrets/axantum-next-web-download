//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AxDecrypt.rc
//
#define IDR_MANIFEST                    1
#define IDC_MYICON                      2
#define IDC_BTN_MORE                    3
#define IDD_AXDECRYPT_DIALOG            102
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDM_FILE_EXIT                   105
#define IDI_AXDECRYPT                   107
#define IDC_AXDECRYPT                   109
#define IDS_AXDECRYPT                   110
#define IDS_AXCRYPT                     111
#define IDS_DEFAULTFILENAME             112
#define IDS_AXCRYPTURL                  113
#define IDD_AXDECRYPT                   114
#define IDS_AXEXT                       114
#define IDS_HELPMSG                     115
#define IDS_DECRYPTING                  116
#define IDS_FOLDER                      117
#define IDS_OPENING                     118
#define IDS_ABOUTMSG                    119
#define IDS_APP_TITLE_FILE              120
#define IDS_COPYNOTOK                   120
#define IDS_ABOUTTITLE                  121
#define IDS_DEFKEYFILE                  122
#define IDS_EXEWARN                     123
#define IDS_FILEMSG                     124
#define IDS_COPYOK                      125
#define IDS_MORE                        126
#define IDS_WRONGPASSPHRASE             127
#define IDR_MAINFRAME                   128
#define IDS_STATUS                      128
#define IDD_PASSPHRASE                  129
#define IDS_TOOPEN                      129
#define IDD_PROGRESS                    131
#define IDD_HELP                        132
#define IDR_RT_MANIFEST1                134
#define IDM_FILE_COPYAXDECRYPTTO        136
#define IDC_EDIT_PASSPHRASE             1000
#define IDC_BUTTON1                     1001
#define IDS_OPERATION                   1001
#define IDC_GETAXCRYPT                  1001
#define IDC_EDIT_KEYFILE                1001
#define IDS_FILE                        1002
#define IDC_PROGRESS                    1003
#define IDC_DECRYPT                     1004
#define IDC_FOLDER                      1005
#define IDC_BROWSE                      1006
#define IDC_ABOUT                       1008
#define IDC_HELPBUTTON                  1009
#define IDC_OVERWRITE                   1010
#define IDC_PASSPHRASE                  1011
#define IDC_OPENAFTER                   1012
#define IDC_STATUS                      1013
#define IDC_PROMPT                      1014
#define IDC_HELPMSG                     1015
#define IDC_COPYRIGHT                   1018
#define IDC_ABOUTMSG                    1019
#define IDC_BTN_KEYFILE                 1021
#define IDM_FILE_OPEN                   32771
#define IDM_FILE_KEY                    32772
#define IDM_HELP_CONTENTS               32773
#define IDM_HELP_ABOUT                  32774
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
