//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AxCryptShellExt.rc
//
#define MANIFEST_RESOURCE_ID            2
#define IDD_DIALOG1                     101
#define IDD_PROPSHEETPAGE               101
#define IDD_PROGRESS                    103
#define IDD_BRUTEFORCE                  104
#define IDD_ABOUT                       106
#define IDB_AXCRYPT                     107
#define IDC_ABOUT                       1000
#define IDC_ENC_LEAD                    1001
#define IDC_COMP_LEAD                   1002
#define IDC_AUTH_LEAD                   1003
#define IDC_ENC                         1004
#define IDC_COMP                        1005
#define IDC_AUTH                        1006
#define IDC_ABOUT_GROUP                 1007
#define IDC_RAND_LEAD                   1008
#define IDC_BRUTEFORCE                  1008
#define IDC_RAND                        1009
#define IDC_LISTABOUT                   1009
#define IDC_BTN_NOTIFY                  1010
#define IDC_BTN_DOCS                    1011
#define IDC_INF_ABOUT                   1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
