//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AxCrypt.rc
//
#define IDD_ENTERPASSPHRASE             102
#define IDD_OLDNEWPASSPHRASE            103
#define IDD_EMPTY                       109
#define IDD_LICENSE                     109
#define IDD_WARNING                     113
#define IDD_PROGRESS                    114
#define IDD_DIALOG1                     123
#define IDD_NEWPASSPHRASE               123
#define IDD_DIALOG2                     124
#define IDD_PASSPHRASE                  124
#define IDD_OLD2PASSPHRASE              125
#define IDI_ICON1                       130
#define IDI_AXCRYPT                     130
#define IDD_REGISTRATION                132
#define IDC_PASSPHRASE                  1000
#define IDC_NEWPASSPHRASE1              1001
#define IDC_PASSPHRASE2                 1002
#define IDC_NEWPASSPHRASE2              1003
#define IDC_ENTER_PASS                  1005
#define IDC_ENTER_VERIFY                1006
#define IDS_FILENAME                    1006
#define IDC_CHECKCACHE                  1007
#define IDC_CHECKMSG                    1008
#define IDC_MSG                         1010
#define IDC_BUTTONKEYBROWSE             1011
#define IDC_EDITKEYFILE                 1014
#define IDS_KEYFILENAME                 1015
#define IDC_KEYFILE                     1016
#define IDC_CHECKCACHE_D                1018
#define IDC_CHECKCACHE_E                1019
#define IDC_ENTER_SIGNATURE             1020
#define IDC_LICENSEE                    1021
#define IDC_SIGNATURE                   1022
#define IDC_ENTER_LICENSEE              1023
#define IDC_BADLIC                      1024
#define IDC_ERRICON                     1025
#define IDC_ENTER_REGISTRATION          1026
#define IDC_ENTERREGISTRATION           1026
#define IDC_REGISTRATIONEMAIL           1027
#define IDC_TRYXECRETS                  1030
#define IDC_STATIC                      -1
#define IDC_REGISTRATIONPROMPT          -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
