#ifndef DYNLOADSTRING_H
#define DYNLOADSTRING_H
extern _TCHAR *DynLoadString(UINT uId, HMODULE hModule = NULL);
#endif
