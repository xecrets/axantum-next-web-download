#ifndef GETMODULEFILENAME_H
#define GETMODULEFILENAME_H
extern _TCHAR *MyGetModuleFileName(HINSTANCE hModule);
#endif
